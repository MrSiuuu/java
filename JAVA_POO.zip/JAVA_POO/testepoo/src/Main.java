import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        Boutique maBoutique = new Boutique();

        maBoutique.addProduit(new ProduitAlimentaire("carton de poulet", "carton de poulet", LocalDate.of(2023, 5, 15), 100));
        maBoutique.addProduit(new ProduitAlimentaire("carton de poulet", "carton de poulet", LocalDate.of(2023, 5, 15), 100));
        maBoutique.addProduit(new ProduitElectronique("Iphone", "Dernier iphone", 14, 650));
        maBoutique.addProduit(new ProduitElectronique("McBook", "Dernier Mac", 14, 5650));
        maBoutique.addProduit(new ProduitBoisson("Vodka", "Vin", 500, 35));
        maBoutique.addProduit(new ProduitBoisson("lait_Pur", "lait_Pur", 400, 15));

        Panier monPanier = new Panier();
        monPanier.ajouterProduit(new ProduitAlimentaire("carton de poulet", "carton de poulet", LocalDate.of(2023, 5, 15), 100));
        monPanier.ajouterProduit(new ProduitElectronique("Iphone", "Dernier iphone", 14, 650));
        monPanier.ajouterProduit(new ProduitElectronique("McBook", "Dernier Mac", 14, 5650));
        monPanier.ajouterProduit(new ProduitBoisson("Vodka", "Vin", 500, 35));
        monPanier.ajouterProduit(new ProduitBoisson("lait_Pur", "lait_Pur", 400, 15));

        System.out.println("Le prix total du panier est : " + monPanier.prixTotalPanier() + "€");
        maBoutique.afficherStock();
    }
}
